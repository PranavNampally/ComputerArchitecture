
# Online Python - IDE, Editor, Compiler, Interpreter
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt
import numpy as np
prob = []
width = []
time = []

f = open("abc.txt", "rt")

for x in f:
    x = x.strip().split(" ")
    print(x)
    p = float(x[1])
    w = int(x[2])
    t = float(x[0])
    prob.append(p)
    width.append(w)
    time.append(t)
f.close()

fig = plt.figure()
x = np.array(prob)
y = np.array(width)
z = np.array(time)

graph = fig.add_subplot(111, projection = '3d', xlabel='Probability', ylabel='Width', zlabel='Time(s)')
graph.set_title('3D plot of probability, width and time')
graph.plot(xs=prob, ys=width, zs=time)
plt.show()
fig.savefig('graph.png')
