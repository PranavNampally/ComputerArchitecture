package generic;

public class DivEvent extends Event {


	public DivEvent(long eventTime, Element requestingElement, Element processingElement) {
		super(eventTime, EventType.DivStart, requestingElement, processingElement);
	}
}
