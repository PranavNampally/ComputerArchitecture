package generic;

public class AluEndEvent extends Event {

	public AluEndEvent(long eventTime, Element requestingElement, Element processingElement) {
		super(eventTime, EventType.AluEnd, requestingElement, processingElement);
	}

}
