package generic;

public class MulEvent extends Event {


	public MulEvent(long eventTime, Element requestingElement, Element processingElement) {
		super(eventTime, EventType.MulStart, requestingElement, processingElement);
	}
}
