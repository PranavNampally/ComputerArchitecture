package generic;

public class AluStartEvent extends Event {


	public AluStartEvent(long eventTime, Element requestingElement, Element processingElement) {
		super(eventTime, EventType.ALuStart, requestingElement, processingElement);
	}
}
