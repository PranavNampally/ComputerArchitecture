package processor.pipeline;

import configuration.Configuration;
import generic.*;
import processor.Clock;
import processor.Processor;

public class InstructionFetch implements Element{
	
	Processor containingProcessor;
	IF_EnableLatchType IF_EnableLatch;
	IF_OF_LatchType IF_OF_Latch;
	EX_IF_LatchType EX_IF_Latch;
	
	public InstructionFetch(Processor containingProcessor, IF_EnableLatchType iF_EnableLatch, IF_OF_LatchType iF_OF_Latch, EX_IF_LatchType eX_IF_Latch)
	{
		this.containingProcessor = containingProcessor;
		this.IF_EnableLatch = iF_EnableLatch;
		this.IF_OF_Latch = iF_OF_Latch;
		this.EX_IF_Latch = eX_IF_Latch;
	}
	
	public void performIF() {
		if(containingProcessor.getStopPipeline()){
			System.out.println("IF Stage:PIPELINE STOPPED");
			return;
		}



		if (IF_EnableLatch.isIF_enable()) {
			System.out.println("IF Stage:");
			int newInstruction = -1;
			boolean createEvent_flag=false;
			System.out.println(containingProcessor.getRegisterFile().getProgramCounter());
			if (EX_IF_Latch.getIsBranchTaken()) {
				containingProcessor.getRegisterFile().setProgramCounter(EX_IF_Latch.getbranchTarget());
				int currentPC = containingProcessor.getRegisterFile().getProgramCounter();

				newInstruction = containingProcessor.getMainMemory().getWord(currentPC);
				createEvent_flag=true;

				EX_IF_Latch.setIsBranchTarget(false);
				currentPC += 1;
				containingProcessor.getRegisterFile().setProgramCounter(currentPC);
				System.out.println("Branch: " + currentPC + " " + newInstruction);
			} else {
				int currentPC = containingProcessor.getRegisterFile().getProgramCounter();

				newInstruction = containingProcessor.getMainMemory().getWord(currentPC);
				createEvent_flag=true;

				currentPC += 1;
				containingProcessor.getRegisterFile().setProgramCounter(currentPC);
				System.out.println("Branch: " + currentPC + " " + newInstruction);
			}

			if(createEvent_flag){
				Simulator.getEventQueue().addEvent(
						new MemoryReadEvent(
								Clock.getCurrentTime() + Configuration.mainMemoryLatency,
								this,
								containingProcessor.getMainMemory(),
								0
						)
				);
			}




			// System.out.println(currentPC+" "+newInstruction);
			//			System.out.println(containingProcessor.getMainMemory().getContentsAsString(0, 100));
			IF_OF_Latch.setInstruction(newInstruction);
			Statistics.setNumberOfInstructions(Statistics.getNumberOfInstructions() + 1);
			IF_OF_Latch.setOF_enable(true);
		}

	}

	@Override
	public void handleEvent(Event e) {
		MemoryResponseEvent event = (MemoryResponseEvent) e;
//		if(IF_OF_Latch.isOF_enable()){
//			e.setEventTime(Clock.getCurrentTime()+1);
//			Simulator.getEventQueue().addEvent(e);
//		}
//		else{
//
////			IF_OF_Latch.setInstruction((event.getValue()));
//		}
	}
}
