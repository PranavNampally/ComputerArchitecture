package processor;

import generic.*;

public class ALU implements Element {

    @Override
    public void handleEvent(Event e) {
        if(e.getEventType()== Event.EventType.ALuStart){
            AluStartEvent event = (AluStartEvent) e;
            Simulator.getEventQueue().addEvent(
                    new AluEndEvent(
                            Clock.getCurrentTime(),
                            this,
                            event.getRequestingElement()
                    )
            );
        }
        if(e.getEventType()== Event.EventType.MulStart){
            MulEvent event = (MulEvent) e;
            Simulator.getEventQueue().addEvent(
                    new AluEndEvent(
                            Clock.getCurrentTime(),
                            this,
                            event.getRequestingElement()
                    )
            );
        }
        if(e.getEventType()== Event.EventType.DivStart){
            DivEvent event = (DivEvent) e;
            Simulator.getEventQueue().addEvent(
                    new AluEndEvent(
                            Clock.getCurrentTime(),
                            this,
                            event.getRequestingElement()
                    )
            );
        }
    }
}
